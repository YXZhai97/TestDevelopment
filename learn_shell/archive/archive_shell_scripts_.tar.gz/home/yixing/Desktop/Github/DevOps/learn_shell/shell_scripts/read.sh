#!/bin/bash

read -t 10 -p "please input your name:" name
echo "Welcome, $name"

