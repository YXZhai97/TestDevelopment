#!/bin/bash
echo "Hello World"
echo $my_var
echo $new_var

