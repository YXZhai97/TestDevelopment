#!/bin/bash

case $1 in 
1)
	echo "Monday"
;;
2)
	echo "Tuesday"
;;
3)
	echo "Wen"
;;
*)
	echo "Other weekdays"
;;
esac


