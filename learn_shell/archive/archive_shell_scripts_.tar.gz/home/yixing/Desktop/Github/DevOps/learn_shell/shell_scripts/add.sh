#!/bin/bash 
sum=$[$1+$2]
echo sum=$sum 


